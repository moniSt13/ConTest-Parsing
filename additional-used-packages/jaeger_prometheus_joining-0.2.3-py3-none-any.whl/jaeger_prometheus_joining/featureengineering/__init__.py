"""
These classes add additional information based on existing data. It follows the same schema as the transformationscripts.
 A start method shall exist which handles every operation.
"""
