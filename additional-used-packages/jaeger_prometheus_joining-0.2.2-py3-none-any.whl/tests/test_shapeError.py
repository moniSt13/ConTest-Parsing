import polars as pl

#series_max_depth = 0.5

#series_spanID = [['e16ed001c22412e2', '96b8558f33ca0d02']]

#read json file single_traces.csv

def convert_to_str(series):
    result = []
    for sublist in series:
        for item in sublist[0]:
            result.append(item)
    return pl.Series(result)

single_service_json = pl.read_csv("single_service_json_failure.csv").to_dict()

print("Series_max_depth:", single_service_json['mean_max_depth'])
print("Series_spanID:", single_service_json['spanID'])

#convert column to list
single_service_json['spanID'] = list(single_service_json['spanID'][0])



print("SpanID:", single_service_json['spanID'])

#spanID = convert_to_str(spanID)



single_service_df = (
                        pl.DataFrame(
                            single_service_json,
                        )
                    ).with_columns(
                    [
                    pl.col("spanID").list.join(" - ")#pl.col("spanID")
                    ]
                    )

print(single_service_df)



