import polars as pl


#read csv file
df = pl.read_csv("df_withsinglelinetraces.csv")


print(df.glimpse())

#size of df
print(df.shape)

#print last 50 COLUMNS of df

df_tail = df[:,-200:]
df_tail.write_csv("df_withsinglelinetraces_last50columns.csv")