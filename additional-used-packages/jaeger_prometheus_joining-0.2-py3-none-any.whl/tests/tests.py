import polars as pl
import regex as re

df = pl.DataFrame(

    {

        "foo": [1, 2, 3, 4, 5],

        "bar": [6.0, 7.0, 8.0, 9.9, 10.0],

        "ham": ["a", "b", "c", "d", "e"], #kann c überhaupt immer null sein???


    }

)

other_df = pl.DataFrame(

    {

        "apple": [33, 44, 55, 66],

        "ham": ["a", "b", "a", "c"],

    }

)

other_df_2 = pl.DataFrame(

    {

        "apple": [2],
        "ham": ["d"]

    }
)

other_df_3 = pl.DataFrame(
    {
        "apple": [3],
        "ham": ["e"]
    }
)


i = 0
df_joined = df.join(other_df, on="ham", how="left", suffix=str(i))
i = i+1
df_joined = df_joined.join(other_df_2, on="ham", how="left", suffix=str(i))
i = i+1




df_joined = df_joined.join(other_df_3, on="ham", how="left", suffix=str(i))
i = i+1
tmp_list_columnames = []
for ii in range(i):
    tmp_list_columnames.append([col for col in df_joined.columns if str(ii) in col])
startElement = tmp_list_columnames[1]
pattern = r'[0-9]'
print("startElement:", startElement[0])
newElement = re.sub(pattern, '', startElement[0])
print("startElement:", newElement)
tmp_list_columnames[0] = newElement
print("list:", tmp_list_columnames)


print(df_joined)

for columnsToChange in tmp_list_columnames:
    print("columnsToChange:", columnsToChange)
    #concat all columns with the same suffix

df_joined = df_joined.with_columns(df_joined.select(
    pl.concat_list(pl.selectors.starts_with(x)).alias(x) for x in ['apple', 'apple1', 'apple2']#columnsToChange
))
# print first element of each row

print("df apple:", df_joined['apple'])

tmp_list_for_s = []
for n in range(len(df_joined['apple'])):
    for list_length in range(len(df_joined['apple'][n])):
        if df_joined['apple'][n][list_length] != None:
            tmp = df_joined['apple'][n][list_length]
            print("df apple_run_list_length:", df_joined['apple'][n][list_length])
            tmp_list_for_s.append(tmp)
            

s = pl.Series("apple_fertig", tmp_list_for_s)
print("tmp_list_for_s:", s)
df_joined = df_joined.hstack([s])

print("df_joined before cleaned:", df_joined)

#delete rows in that include columns_to_change
for columnsToChange in tmp_list_columnames:
    df_joined = df_joined.drop(columnsToChange)


print("df_joined AFTER cleaned:", df_joined)








