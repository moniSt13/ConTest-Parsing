"""
Utility scripts which don't belong in any package. Currently there are:
* a timedecorator to caluclate the runtime of a given function
* combinatorics to get all possible combinations
* the whole visualization module
"""
